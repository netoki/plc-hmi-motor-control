def handleTimerEvent():
	path = "[default]HeartbeatIn"
	tag = system.tag.readBlocking([path])[0]
	
	if tag.quality.isGood():
		system.tag.writeBlocking([path], [(tag.value + 1) % 1000])